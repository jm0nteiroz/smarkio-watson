import styled from 'styled-components'

export const ForgotAndRegister = styled.div`
  text-align: right;
`

export default ForgotAndRegister
