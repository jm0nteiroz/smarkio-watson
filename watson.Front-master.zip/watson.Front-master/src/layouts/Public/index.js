// eslint-disable-next-line no-unused-vars
import { withRouter } from 'react-router-dom'

const PublicLayout = ({ children }) => {
  return children
}

export default withRouter(PublicLayout)
