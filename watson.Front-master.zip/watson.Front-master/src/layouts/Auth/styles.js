import styled from 'styled-components'

export const WatsonStyle = styled.div`
  padding-right: 20%;
  padding-left: 20%;
  padding-top: 10%;
`

export default WatsonStyle