import api from './api'

export const getComments = () => {
  return api.get('/comment')
}

export const saveComments = (value) => {

      const texto = value
      const fs = require('fs');
      const TextToSpeechV1 = require('ibm-watson/text-to-speech/v1');
      const { IamAuthenticator } = require('ibm-watson/auth');
      const textToSpeech = new TextToSpeechV1({
          authenticator: new IamAuthenticator({ apikey: 'tYA8LjdTeDM6aL7cXheXtcFk2lDdLhKr4y9uP0lhctoC' }),
          url: 'https://api.us-south.text-to-speech.watson.cloud.ibm.com/instances/e06365c1-ac2e-441b-b16b-9f45f517c107'
      });
      const params = {
          text: texto,
          voice: 'pt-BR_IsabelaVoice', // Optional voice
          accept: 'audio/wav'
      };

      textToSpeech
      //transforma o texto em audio
          .synthesize(params)
          .then(response => {
              const audio = response.result;
              return textToSpeech.repairWavHeaderStream(audio);
          })
          .then(repairedFile => {
              fs.writeFileSync('../upload/' + value + 'audio.wav', repairedFile);
              console.log(value + 'audio.wav foi inserido!');
          })
          .catch(err => {
              console.log(err);
          });

  api.post("/comment", {
      comment: value
  })
}